lab_links = {
    0: "link",
}

homework_links = {
   0: "google.com",
}