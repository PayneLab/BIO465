from . import BIO465
from . import Assignment
from . import Lab
from . import Homework
from BIO465 import BIO465